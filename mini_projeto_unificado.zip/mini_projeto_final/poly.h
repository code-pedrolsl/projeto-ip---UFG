void le_nome(char * s, char * sd); 
void maior_grau(char * s, int *grau);
void coeficiente(char * s, double coefi[]);
void acha_poly(char * s, char * P1, char * P2, char *sn);