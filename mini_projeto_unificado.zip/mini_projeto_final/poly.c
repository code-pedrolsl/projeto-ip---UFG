#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void le_nome(char * s, char * sd){
    int i;
    char nome[100];

    for(i = 0; s[i]!=':'; i++){
        sd[i] = s[i];
    }
    sd[i] = '\0';
}
void maior_grau(char * s, int *grau){                  
    int i, k, j, tam;
    char num_str[101];
    double num1 = 0.00, num;
    tam = strlen(s);

    for(i = 0; i < tam; i++){
        if(s[i] == '^'){
            j = 0;
            for(k = i+1; s[k]!='+' && s[k]!='-' && s[k]!='\0'; k++){
                num_str[j] = s[k];
                j++;
            }
            num = atof(num_str);
            if(num > num1) num1 = num;
        }
    }
    *grau = (int)num1;
}
void coeficiente(char *s, double coefi[]){
    int i, j, k, tam;
    int a = 0, b = 0;
    int negativo; //0 = positivo, i = negativo

    char num_str[101];

    double num1 = 0.00, num;
    double aux, co[101], pot[101]; //coeficiente e grau;
    tam = strlen(s);

    //separa coeficientes em vetor
    for(i = 0; i < tam; i++){
        negativo = 0;
        if(s[i] == ' ' || s[i] == '+' || s[i] == '-'){
            j = 0;
            if(s[i+1] == '-'){ //caso em que o primeiro coeficiente e negativo
                for(k = i+2; s[k] != 'x'; k++){
                    num_str[j] = s[k];
                    j++;
                }
                co[a] = (-1) * atof(num_str); //coeficiente
                a++;
            }
            else{
                for(k = i+1; s[k] != 'x'; k++){
                    if(s[i] == '-') negativo = 1;

                    num_str[j] = s[k];
                    j++;
                }
                co[a] = atof(num_str); //coeficiente
                if(negativo == 1) co[a] *= (-1);
                a++;
            }
        }
    }
    //separa potencias em vetor
    for(i = 0; i < tam; i++){
        if(s[i] == '^'){
            j = 0;
            for(k = i+1; s[k]!='+' && s[k]!='-' && s[k]!='\0'; k++){
                num_str[j] = s[k];
                j++;
            }
            num = atof(num_str);
            if(num > num1) num1 = num; //maior grau;
            pot[b] = num;
            b++;
        }
    }
    //organiza coeficiente
    for(i = 0; i <= num1; i++){
        for(k = 0; k < b; k++){
            if(i == pot[k]){
                coefi[i] = co[k];
                break;
            }
            else{
                coefi[i] = 0;
            }
        }
    }
}
void acha_poly(char * s, char * P1, char * P2, char *sn){
    int i, k, j, cont = 0;
    int tam = strlen(s);

    for(i = 0; i < tam; i++){
        if(cont == 0){
            for(k = 0; s[k] != '+' && s[k] != '-'; k++){
                P1[k] = s[k];
            }
            P1[k] = '\0';
            cont++;
        }
        else{
            j = 0;
            if(s[i] == '+' || s[i] == '-'){
                *sn = s[i];
                for(k = i+1; s[k] != '\0'; k++){
                    P2[j] = s[k];
                    j++;
                }
                P2[j] = '\0';
                break;
            }
        }
    }
}