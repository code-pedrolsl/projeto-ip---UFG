#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "poly.h"

typedef struct{
	char *id;       // string com o nome do polinômio
	int p;          // grau do polinômio
	double *coef;   // vetor de coeficientes do polinômio
} Poly;

int main(){
    int casos, operacoes, menor;
    int qtd = 0, i, k, j, P;
    int zero; //confere se a operacao deu 0 ou nao

    double coefi[101];
    double *resultado, result[1001];

    char str[101], op[101], name[101];
    char p1[101], p2[101], sinal; 

    Poly *poly = NULL;

    scanf("%d%*c", &casos);
    poly = (Poly*) calloc (casos, sizeof(Poly));
    poly[qtd].coef = (double*) malloc (1 * sizeof(double));
    resultado = (double*) calloc (1, sizeof(double));

    while(casos > 0){
        scanf("%[^\n]%*c", str);

        //LEITURA DO NOME DO POLINOMIO:
        le_nome(str, name);        
        poly[qtd].id = (char*) malloc ((strlen(name)+1) * sizeof(char));
        strcpy(poly[qtd].id, name);

        //IDENTIFICA MAIOR GRAU DO POLINOMIO:
        maior_grau(str, &P);
        poly[qtd].p = P;
        poly[qtd].coef = (double*) realloc (poly[qtd].coef, (P+1) * sizeof(double));

        //ORGANIZA COEFICIENTE
        coeficiente(str, coefi);
        for(i = 0; i <= P; i++){
            poly[qtd].coef[i] = coefi[i];
        }
        qtd++;
        casos--;
    }
    scanf("%d%*c", &operacoes);
    while(operacoes > 0){
        scanf("%[^\n]%*c", op);

        //IDENTIFICA OS POLINOMIOS DA OPERACAO E SE ELA SOMA OU SUBTRAI
        acha_poly(op, p1, p2, &sinal);

        for(i = 0; i < qtd; i++){
            if(strcmp(poly[i].id, p1)==0)
                break;
        }
        for(k = 0; k < qtd; k++){
            if(strcmp(poly[k].id, p2)==0)
                break;
        }
        if(sinal == '+'){ //soma
            if(poly[i].p > poly[k].p){
                P = poly[i].p;
                for(j = 0; j <= poly[k].p; j++){
                    result[j] = poly[i].coef[j] + poly[k].coef[j];
                }
                for(j = poly[k].p+1; j <= P; j++){
                    result[j] = poly[i].coef[j];
                }
            }
            else{
                P = poly[k].p;
                for(j = 0; j <= poly[i].p; j++){
                    result[j] = poly[i].coef[j] + poly[k].coef[j];
                }
                for(j = poly[i].p+1; j <= P; j++){
                    if(poly[i].p == poly[k].p) break;
                    result[j] = poly[k].coef[j];
                }
            }
        }
        else{ //subtracao -> poly[k] multiplica por (-1)
            if(poly[i].p > poly[k].p){
                P = poly[i].p;
                for(j = 0; j <= poly[k].p; j++){
                    result[j] = poly[i].coef[j] - poly[k].coef[j];
                }
                for(j = poly[k].p+1; j <= P; j++){
                    result[j] = poly[i].coef[j];
                }
            }
            else{
                P = poly[k].p;
                for(j = 0; j <= poly[i].p; j++){
                    result[j] = poly[i].coef[j] - poly[k].coef[j];
                }
                for(j = poly[i].p+1; j <= P; j++){
                    if(poly[i].p == poly[k].p) break;
                    result[j] = -poly[k].coef[j];
                    if(result[j] == -0) result[j] *= (-1);
                }
            }
        }
        zero = 0;
        for(i = 0; i <= P; i++){
            if(result[i] > 0 || result[i] < 0){
                zero = 1;
                break;
            }
        }
        if(zero == 0) printf("0.00x^0\n");
        else{
            for(i = 0; i <= P; i++){
                if(i==0 && result[i]>0) printf("%.2lfx^%d", result[i], i);
                if(i!=0 && result[i]>0) printf("+%.2lfx^%d", result[i], i);
                if(result[i]<0) printf("%.2lfx^%d", result[i], i);
            }
            printf("\n");
        }

        for(i = 0; i <= P; i++) result[j] = 0; //zera vetor pra evitar lixo de memoria
        operacoes--;
    }
    for(i = 0; i < casos; i++){
        free(poly[i].id);
    }
    for(i = 0; i < casos; i++){
        free(poly[i].coef);
    }
    free(poly);

    return 0;
}